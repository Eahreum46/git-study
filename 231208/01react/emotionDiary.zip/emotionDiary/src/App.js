import "./App.css";
import React, { useState, useReducer, useRef, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import New from "./pages/New";
import Diary from "./pages/Diary";
import Edit from "./pages/Edit";

//기본 mockup 데이터 만들기
const mockData = [
  {
    id: "mock1",
    date: new Date().getTime() - 1,
    content: "임시로 작성된 내용1",
    emotionId: 1,
  },
  {
    id: "mock2",
    date: new Date().getTime() - 2,
    content: "임시로 작성된 내용2",
    emotionId: 2,
  },
  {
    id: "mock3",
    date: new Date().getTime() - 3,
    content: "임시로 작성된 내용3",
    emotionId: 3,
  },
];

//App 밖에 선언
const reducer = (state, action) => {
  switch (action.type) {
    case "INIT": {
      return action.data;
    }
    case "CREATE": {
      return [action.data, ...state];
      //나머지는 초기값 state을 반환
    }
    case "UPDATE": {
      //바뀌었으면 새로 적용시키고, 아니면 원래걸로 가자
      return state.map((it) =>
        String(it.id) === String(action.data.id) ? { ...action.data } : it
      );
      //String으로 미리 바꿔놓아 꼬이지 않게 한다? 배열 안에 들어갈 값이니까?
    }
    case "DELETE": {
      //삭제는 filter를 써서 다시 랜더링하는 방식으로 구현
      return state.filter((it) => String(it.id) !== String(action.targetId));
    }
    default: {
      return state;
    }
  }
};
//state: data에 반영될 정리된 상태
//action으로 값을 받아옴

//context 사용하기(바운더리 생성)-> 부모로부터 데이터를 받아서 뿌려주는 역할
export const DiaryStateContext = React.createContext(); //원본 데이터 값
export const DiaryDispatchContext = React.createContext(); //함수 데이터 값으로 이원화

const App = () => {
  const [isDataLoaded, setIsDataLoaded] = useState(false);

  //dispatch : 상태변화를 일으키고, 구분짓는 함수
  //reducer : 상태 변화에 따라서 실제 실행하게 하는 실행부의 함수
  // [] : state변수에 담길 초기값
  const [data, dispatch] = useReducer(reducer, []);
  const idRef = useRef(0);
  useEffect(() => {
    dispatch({
      type: "INIT",
      data: mockData,
    });
    setIsDataLoaded(true); //처음 로드되어 목업데이터가 data에 가게 되면 isDataLoaded를 true로 한다.
    //정상적으로 데이터가 로드되지 않으면 실행되지 않도록 하기 위함.(된장찌개 비유)
  }, []); //의존성 배열 자리에 빈 배열을 넣을 경우, 컴포넌트가 마운트(탄생)되었을 때 한 번만 실행된다.

  const onCreate = (date, content, emotionId) => {
    dispatch({
      type: "CREATE",
      data: {
        id: idRef.current,
        date: new Date(date).getTime(),
        content,
        emotionId,
      },
    });
    idRef.current += 1;
  };

  const onUpdate = (targetId, date, content, emotionId) => {
    //dispatch 안에 객체 형태로 값을 쪼갠다.
    dispatch({
      type: "UPDATE",
      data: {
        id: targetId,
        date: new Date(date).getTime(),
        //새롭게 바뀐 content, emotionId 적용
        content,
        emotionId,
      },
    });
  };

  const onDelete = (targetId) => {
    dispatch({
      type: "DELETE",
      targetId,
      //targetId만 있어도 삭제는 되니까
    });
  };

  //아직 데이터를 가져오지 못했을 때
  if (!isDataLoaded) {
    return <div>데이터를 불러오는 중입니다.</div>;
  } else {
    //dispatch를 활용해서 목업데이터를 정상적으로 넘겨주었을 떄.
    return (
      <DiaryStateContext.Provider value={data}>
        <DiaryDispatchContext.Provider value={{ onCreate, onUpdate, onDelete }}>
          <div className="App">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/New" element={<New />} />
              <Route path="/Diary/:id" element={<Diary />} />
              {/* <Route path="/Diary" element={<Diary />} /> */}
              <Route path="/Edit/:id" element={<Edit />} />
            </Routes>
            {/* 
        <div>
          <Link to={"/"}>Home</Link>
          <Link to={"/New"}>New</Link>
          <Link to={"/Diary"}>Diary</Link>
          <Link to={"/Edit"}>Edit</Link>
        </div> */}
          </div>
        </DiaryDispatchContext.Provider>
      </DiaryStateContext.Provider>
    );
  }
};
export default App;
